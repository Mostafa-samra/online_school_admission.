import 'package:flutter/material.dart';

abstract class ConstColor{
static  Color kWhite45Opacity =const Color(0xffFFFFFF).withOpacity(0.45);
static  Color kWhite =const Color(0xffFFFFFF);
static  Color kLightBlue =const  Color(0xFFCDDDF9);
static  Color kOffWhite =const  Color(0xFFF5F5F5);
static  Color kRoyalBlue =const  Color(0xFF329CFF);
static  Color kGraphite =const  Color(0xFF343342);
static  Color kSkyBlue =const  Color(0xFF7AA5EA);
static  Color kMediumRoyalBlue =const  Color(0xFF037EEE);
static  Color kAliceblue =const  Color(0xFFEFF7FF);
static  Color kCobaltBlue =const  Color(0xFF037EE6);
static  Color kWhisper =const  Color(0xFFF5F5FA);
static  Color kSageGray =const  Color(0xFFEFAEAC);
static  Color kLightLavenderBlue =const  Color(0xFFB7CDED);
static  Color kDoveGray =const  Color(0xFFAAAACC);
static  Color kLightGray =const  Color(0xFFD9D9D9);
static  Color kVeryLightGray =const  Color(0xFFCACCD0);
static  Color kWhisper1 =const Color.fromARGB(255, 129, 129, 129);

}