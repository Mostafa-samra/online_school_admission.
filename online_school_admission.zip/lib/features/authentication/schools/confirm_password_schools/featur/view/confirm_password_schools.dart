import 'package:flutter/material.dart';

import 'widget/confirm_password_schools_body.dart';

class ConfirmPasswordSchoolsView extends StatelessWidget {
  const ConfirmPasswordSchoolsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body:ConfirmPasswordSchoolsViewBody() ,);
  }
}