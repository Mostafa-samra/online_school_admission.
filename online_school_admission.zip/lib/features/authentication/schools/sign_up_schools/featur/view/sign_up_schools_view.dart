import 'package:flutter/material.dart';

import 'widget/sign_up_schools_view_body.dart';

class SignUpSchoolsView extends StatelessWidget {
  const SignUpSchoolsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body:SignUpSchooksViewBody() ,);
  }
}