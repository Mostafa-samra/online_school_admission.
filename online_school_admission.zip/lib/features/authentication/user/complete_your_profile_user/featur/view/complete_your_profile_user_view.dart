import 'package:flutter/material.dart';

import 'widget/complete_your_profile_user_view_body.dart';

class CompleteYourProfileUserView extends StatelessWidget {
  const CompleteYourProfileUserView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: CompleteYourProfileUserViewBody(),
    );
  }
}
