import 'package:flutter/material.dart';
import 'widget/signin_view_user_body.dart';

class SignInUserView extends StatelessWidget {
  const SignInUserView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: SigninViewUserBody());
  }
}
