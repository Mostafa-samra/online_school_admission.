import 'package:flutter/material.dart';

import 'widget/application_submit_view_body.dart';

class ApplicationSubmitPageOneView extends StatelessWidget {
  const ApplicationSubmitPageOneView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body:ApplicationSubmitViewBody() ,);
  }
}