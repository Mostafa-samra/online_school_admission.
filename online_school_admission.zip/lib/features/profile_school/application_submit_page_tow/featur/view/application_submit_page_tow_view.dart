import 'package:flutter/material.dart';

import 'widget/application_submit_page_tow_view_body.dart';

class ApplicationSubmitPageTowView extends StatelessWidget {
  const ApplicationSubmitPageTowView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: ApplicationSubmitPageTowViewBody(),);
  }
}