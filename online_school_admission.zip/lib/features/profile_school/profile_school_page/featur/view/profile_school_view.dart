import 'package:flutter/material.dart';

import 'widget/profile_school_view_body.dart';

class ProfileSchoolView extends StatelessWidget {
  const ProfileSchoolView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body:ProfileSchoolViewBody() ,);
  }
}